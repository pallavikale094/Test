<?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  	die('Could not connect: ' . mysql_error());
  }
mysql_select_db("Test", $con); //Replace with your MySQL DB Name

$de= mysql_real_escape_string($_GET["decode"]);

$sql = 'select * from test_url where short_url="$de"';

$result=mysql_query("select * from test_url where short_url='$de'");

while($row = mysql_fetch_array($result))
{
	$res=$row['short_url'];
	header("location:".$res);
}

?>